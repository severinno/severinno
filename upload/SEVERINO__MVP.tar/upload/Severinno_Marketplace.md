SEVERINNO MARKETPLACE SAAS  
Prestação de serviços residenciais, prediais, condominiais, comerciais e industriais  
Projeto todo autogerenciável e auto configurável pelo administrador/root 

Objetivo principal do ecossistema é unir as pontas clientes e prestadores de serviços verificados e qualificados mais próximos um do outro referente a geolocalização.

Nosso hiperfoco é na UX UI experiência do usuário e no designer de serviços. Priorizando usabilidade, acessibilidade, navegabilidade, arquitetura da informação, observalidade, sucesso do cliente e do prestador. Interfaces clean e minimalistas focado no usuário e nos serviços.

SERVIÇOS

**FLUXO de Orçamentos**  
Cliente clica no botão Orçamento no card do prestador.O fluxo de orçamento inicia abre modal de orçamentos. O prestador e o serviço  já vem selecionado por default com opção de selecionar outros prestadores e serviços, afinal cliente pode fazer 1 ou mais  orçamentos de 1 ou mais serviços com vários prestadores de uma só vez. A decisão de escolher o profissional fica a cargo exclusivamente da decisão do cliente.  
Lista de sugestão de prestadores  têm obedecer os seguintes parâmetros ordenação por: 1-maior e melhor avaliação 2-mais próximo (gps)    
INSERIR DESCRIÇÃO DETALHADA DO SERVIÇO  
INSERIR FOTOS DO SERVIÇO A SER PRESTADO (MÁXIMO 4 FOTOS)  
INSERIR QUANTIDADE  SELECIONAR MEDIÇÃO POR: unidade, metro linear, metro quadrado, metro cúbico)   
 (carrega dinamicamente todos serviços que o prestador tem cadastrado)   
 \=\> Inserir descrição \=\> Endereço (digita cep carrega automático endereço) insere número e complemento se tiver (ex: apto 101, sala 2\) podemos oferecer botão minha localização para carregá todo endereço via gps restando somente numero e complemento.

**FLUXO de agendamentos**   
Cliente clica no botão Agendar no card do prestador. O fluxo de agendamento inicia abrindo o modal de agendamentos. O prestador e o serviço  já vem selecionado por default. Nessa situação o cliente poderá efetuar somente um agendamento por vez.

1\) Data e Horário \=\> selecionar   
Component \=\>  ([https://shadcnspace.com/components/calendar](https://shadcnspace.com/components/calendar)) \=\> Calendar 03 \- Time Calendar 

2\) Detalhes \=\> informando todos detalhes do agendamento dia, hora, serviço, profissional, valor 

3\) Pagamento \=\> Cartão ou Pix

**PERSONAGENS**

**Visitante** (usuário não logado) \=\> para fazer orçamentos e agendar serviços o cadastro é obrigatório \=\> informar exceção com mensagem otimizada com opção de fazer cadastro gratuito.

—------------------------------------------------------------------------------------------------------------------------

**Cliente**: Cadastro básico: Nome completo, CPF, email e whatsapp.  
*Painel do Cliente*  
Visão geral \=\> dashboard com visão global de todas informações pertencentes ao cliente.  
Perfil (anexar foto perfil upload da galeria ou selfie)  
Agendamentos \=\> listar todos agendamentos com filtros  por status.   
Orçamentos \=\> lista todos orçamentos com filtros por status.  
Serviços \=\> listar todos serviços contratados com filtros por status  
Financeiro \=\> listar todos pagamentos efetuados com filtros por status, mês e ano.  
Mensagens \=\>   
Avaliações \=\> listar todas avaliações informando dados do prestador  
Favoritos \=\> listar os prestadores que são favoritos do cliente

—------------------------------------------------------------------------------------------------------------------------

**Prestador:** Cadastro básico: Nome completo, CPF ou CNPJ, email e whatsapp  
*Painel do Prestador*  
Visão geral \=\> dashboard com visão global de todas informações pertencentes ao cliente.  
Perfil (anexar foto perfil upload da galeria ou selfie)  
Expediente (disponibilidade) \=\> dinâmico, genérico, auto configurável e auto gerenciável     
Agenda  \=\> mostra toda agenda com todas informações  geradas no agendamento   
Agendamentos \=\> mostra todos agendamentos (  
Orçamentos \=\> lista todos orçamentos   
Serviços \=\> CRUD \- cadastro completo focado nos serviços ( selecionar \=\> categoria pai \=\> categoria filha \=\> subcategoria ) e insere dados como título, descrição, preço (preço sugerido valor mínimo ou seja deverá permitir somente aumentar o preço não permitido diminuir)   
Financeiro \=\> informar tudo referente a pagamentos e transações  
Mensagens  
Avaliações \=\> logo após o cliente marcar o serviço como concluído (pagamento é liberado) temos oportunidade de oferecer para fazer uma avaliação do serviço prestado (1 a 5 estrelas)

—------------------------------------------------------------------------------------------------------------------------

ADMIN:   
É O ROOT DO PROJETO VAI TER ACESSO A TUDO E A TODOS FULL DEFAULT. CRUD.  
TUDO VAI SER CONFIGURÁVEL E AUTOGERENCIÁVEL.  
ACESSO A TODOS PERSONAS, ACESSO ROOT FULL AO MAPA, ACESSO ORÇAMENTOS, SERVIÇOS, AGENDAMENTOS, AGENDA, CLIENTES, PRESTADORES, PAGAMENTOS, CONFIGURAR DESIGN SYSTEM (GENÉRICO E DINÂMICO SÍNCRONO) ,TAXONOMIA (GENÉRICA E DINÂMICA SÍNCRONA AUTOGERENCIADA E AUTO CONFIGURÁVEL COM 3 NÍVEIS \-\> CATEGORIA PAI, CATEGORIA FILHA E SUBCATEGORIA), INTEGRAÇÕES com apis de terceiros pagamentos, mensagens, e mails, previsão tempo . . . (PARA EVITAR MEXER EM CÓDIGO PARA CONFIGURAR SERVIÇO PODEMOS PENSAR EM ALGO TIPO TELA QUE INSERIMOS INFORMAÇÕES PARA ATUALIZAR DIRETAMENTE INSTANTÂNEO E SÍNCRONO O ARQUIVO DE CONFIGURAÇÕES  .ENV)

UI INTERFACE COMPONENTS \=\> 

FRONTEND \=\> Vamos utilizar a biblioteca Shacnspace [https://shadcnspace.com/components](https://shadcnspace.com/components)

UTILIZAR COMPONENTS ABAIXO   
PAINEL DE ADMINISTRAÇÃO:  
[https://shadcnspace.com/blocks/dashboard-ui/dashboard-shell](https://shadcnspace.com/blocks/dashboard-ui/dashboard-shell)

CARDS \- PRESTADOR  
[https://shadcnspace.com/components/accordion](https://shadcnspace.com/components/accordion)  
Accordion 01 \- With Icon & Subtitle   
Accordion 02 \- Multi-Level 

UTILIZAR CAMPOS DE BUSCAS INTERNAS  
[https://shadcnspace.com/components/autocomplete](https://shadcnspace.com/components/autocomplete)  
Autocomplete 04 \- Team Member Search   
Autocomplete 05 \- Async Search 

AVATAR FOTO DE PERFIL  
[https://shadcnspace.com/components/avatar](https://shadcnspace.com/components/avatar)  
Avatar 04 \- Border   
Avatar 05 \- Counter 

BREADCRUMB  
[https://shadcnspace.com/components/breadcrumb](https://shadcnspace.com/components/breadcrumb)

[https://shadcnspace.com/components/alert](https://shadcnspace.com/components/alert)

DATA TABLES  
[https://shadcnspace.com/blocks/dashboard-ui/datatable](https://shadcnspace.com/blocks/dashboard-ui/datatable)

POPUP MODAL \=\> PARA PERFIL DO PRESTADOR

UPLOAD ARQUIVOS

CAROUSEL  
[https://shadcnspace.com/components/carousel](https://shadcnspace.com/components/carousel)

APROVAR ORÇAMENTOS (CLIENTE)  
[https://shadcnspace.com/components/dropdown-menu](https://shadcnspace.com/components/dropdown-menu)  
Dropdown Menu 03 \- Collaborative Requests 

[https://shadcnspace.com/components/collapsible](https://shadcnspace.com/components/collapsible)

[https://shadcnspace.com/components/command](https://shadcnspace.com/components/command)

[https://shadcnspace.com/components/context-menu](https://shadcnspace.com/components/context-menu)

[https://shadcnspace.com/components/dropdown-menu](https://shadcnspace.com/components/dropdown-menu)

[https://shadcnspace.com/components/file-upload](https://shadcnspace.com/components/file-upload)

[https://shadcnspace.com/blocks/dashboard-ui/forms](https://shadcnspace.com/blocks/dashboard-ui/forms)

[https://shadcnspace.com/components/pagination](https://shadcnspace.com/components/pagination)

[https://shadcnspace.com/components/popover](https://shadcnspace.com/components/popover)

[https://shadcnspace.com/components/progress](https://shadcnspace.com/components/progress)

[https://shadcnspace.com/components/radio-group](https://shadcnspace.com/components/radio-group)

[https://shadcnspace.com/components/resizable](https://shadcnspace.com/components/resizable)

[https://shadcnspace.com/components/scroll-area](https://shadcnspace.com/components/scroll-area)

[https://shadcnspace.com/components/select](https://shadcnspace.com/components/select)

[https://shadcnspace.com/components/sheet](https://shadcnspace.com/components/sheet)

[https://shadcnspace.com/blocks/dashboard-ui/sidebars](https://shadcnspace.com/blocks/dashboard-ui/sidebars)

[https://shadcnspace.com/components/skeleton](https://shadcnspace.com/components/skeleton)

[https://shadcnspace.com/components/sonner](https://shadcnspace.com/components/sonner)

[https://shadcnspace.com/components/stepper](https://shadcnspace.com/components/stepper)

[https://shadcnspace.com/components/switch](https://shadcnspace.com/components/switch)

[https://shadcnspace.com/blocks/dashboard-ui/tables](https://shadcnspace.com/blocks/dashboard-ui/tables)

[https://shadcnspace.com/components/tabs](https://shadcnspace.com/components/tabs)

[https://shadcnspace.com/components/toggle](https://shadcnspace.com/components/toggle)

[https://shadcnspace.com/components/toggle-group](https://shadcnspace.com/components/toggle-group)

[https://shadcnspace.com/components/tooltip](https://shadcnspace.com/components/tooltip)

[https://shadcnspace.com/blocks/dashboard-ui/topbars](https://shadcnspace.com/blocks/dashboard-ui/topbars)

[https://shadcnspace.com/blocks/dashboard-ui/dashboard-shell](https://shadcnspace.com/blocks/dashboard-ui/dashboard-shell)

[https://shadcnspace.com/blocks/dashboard-ui/datatable](https://shadcnspace.com/blocks/dashboard-ui/datatable)

Referências: Aplicar conceitos, princípios, métodos, indicações e recomendações do Doutor Jacob Nielsen especialista em experiência do usuário, usabilidade, acessibilidade e design de interação. 

As **10 heurísticas de usabilidade de Nielsen** são um conjunto de princípios propostos por Jakob Nielsen para orientar o design e a avaliação de interfaces de usuário. Elas são amplamente utilizadas em avaliações heurísticas para identificar problemas de usabilidade em sistemas interativos. As heurísticas são:

* Visibilidade do status do sistema  
* Correspondência entre o sistema e o mundo real  
* Controle e liberdade do usuário  
* Consistência e padrões  
* Prevenção de erros  
* Reconhecimento em vez de memorização  
* Flexibilidade e eficiência de uso  
* Estética e design minimalista  
* Ajudar os usuários a reconhecer, diagnosticar e recuperar erros  
* Ajuda e documentação

