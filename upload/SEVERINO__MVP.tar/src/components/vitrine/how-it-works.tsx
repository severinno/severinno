"use client"

/**
 * HowItWorks — 3-step explainer.
 *
 * 1) Busque e compare prestadores próximos
 * 2) Peça orçamento ou agende
 * 3) Avalie após o serviço
 *
 * Minimal, icon-led, emerald accent.
 */

import { Search, CalendarCheck, Star } from "lucide-react"
import { cn } from "@/lib/utils"

const STEPS = [
  {
    icon: Search,
    title: "Busque e compare",
    description:
      "Encontre prestadores verificados pela sua localização. Compare preços, avaliações e distância.",
  },
  {
    icon: CalendarCheck,
    title: "Peça orçamento ou agende",
    description:
      "Solicite um orçamento sob medida ou agende diretamente pelo calendário do prestador.",
  },
  {
    icon: Star,
    title: "Avalie após o serviço",
    description:
      "Após o serviço, avalie o prestador. Sua opinião ajuda a manter a qualidade da comunidade.",
  },
] as const

export default function HowItWorks({
  className,
}: {
  className?: string
}) {
  return (
    <section
      aria-label="Como funciona"
      className={cn(
        "mx-auto w-full max-w-7xl px-4 py-12 sm:px-6 lg:px-8",
        className,
      )}
    >
      <header className="mx-auto mb-6 max-w-2xl text-center">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Como funciona
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Três passos simples para resolver o que você precisa.
        </p>
      </header>

      <ol className="grid grid-cols-1 gap-6 sm:grid-cols-3">
        {STEPS.map((step, idx) => {
          const Icon = step.icon
          return (
            <li
              key={step.title}
              className="relative flex flex-col items-center gap-4 rounded-xl border bg-card p-6 text-center shadow-sm transition-all hover:shadow-md"
            >
              <div className="flex items-center gap-3">
                <span className="relative flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
                  <Icon className="size-6" />
                  <span className="absolute -top-2 -right-2 flex size-6 items-center justify-center rounded-full bg-background text-xs font-bold text-primary ring-1 ring-primary/30">
                    {idx + 1}
                  </span>
                </span>
              </div>
              <h3 className="text-base font-semibold tracking-tight">
                {step.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                {step.description}
              </p>
            </li>
          )
        })}
      </ol>
    </section>
  )
}
